#Question 1:
-- NULL Check for customer
SELECT 
  'customer' AS table_name,
  SUM(customer_id IS NULL) AS missing_customer_id,
  SUM(first_name IS NULL) AS missing_first_name,
  SUM(last_name IS NULL) AS missing_last_name,
  SUM(company IS NULL) AS missing_company,
  SUM(address IS NULL) AS missing_address,
  SUM(city IS NULL) AS missing_city,
  SUM(state IS NULL) AS missing_state,
  SUM(country IS NULL) AS missing_country,
  SUM(postal_code IS NULL) AS missing_postal_code,
  SUM(phone IS NULL) AS missing_phone,
  SUM(fax IS NULL) AS missing_fax,
  SUM(email IS NULL) AS missing_email
FROM customer;
select * from customer;
-- Duplicate Primary Key Check for customer
SELECT customer_id, COUNT(*) AS duplicate_count
FROM customer
GROUP BY customer_id
HAVING COUNT(*) > 1;

-- NULL Check for invoice
SELECT 
  'invoice' AS table_name,
  SUM(invoice_id IS NULL) AS missing_invoice_id,
  SUM(customer_id IS NULL) AS missing_customer_id,
  SUM(invoice_date IS NULL) AS missing_invoice_date,
  SUM(billing_address IS NULL) AS missing_billing_address,
  SUM(billing_city IS NULL) AS missing_billing_city,
  SUM(billing_state IS NULL) AS missing_billing_state,
  SUM(billing_country IS NULL) AS missing_billing_country,
  SUM(total IS NULL) AS missing_total
FROM invoice;

-- Duplicate Primary Key Check for invoice
SELECT invoice_id, COUNT(*) AS duplicate_count
FROM invoice
GROUP BY invoice_id
HAVING COUNT(*) > 1;

-- NULL Check for invoice_line
SELECT 
  'invoice_line' AS table_name,
  SUM(invoice_line_id IS NULL) AS missing_invoice_line_id,
  SUM(invoice_id IS NULL) AS missing_invoice_id,
  SUM(track_id IS NULL) AS missing_track_id,
  SUM(unit_price IS NULL) AS missing_unit_price,
  SUM(quantity IS NULL) AS missing_quantity
FROM invoice_line;

-- Duplicate Primary Key Check for invoice_line
SELECT invoice_line_id, COUNT(*) AS duplicate_count
FROM invoice_line
GROUP BY invoice_line_id
HAVING COUNT(*) > 1;

-- NULL Check for track
SELECT 
  'track' AS table_name,
  SUM(track_id IS NULL) AS missing_track_id,
  SUM(name IS NULL) AS missing_name,
  SUM(album_id IS NULL) AS missing_album_id,
  SUM(media_type_id IS NULL) AS missing_media_type_id,
  SUM(genre_id IS NULL) AS missing_genre_id,
  SUM(composer IS NULL) AS missing_composer,
  SUM(milliseconds IS NULL) AS missing_milliseconds,
  SUM(unit_price IS NULL) AS missing_unit_price
	FROM track;

-- Duplicate Primary Key Check for track
SELECT track_id, COUNT(*) AS duplicate_count
FROM track
GROUP BY track_id
HAVING COUNT(*) > 1;

-- NULL Check for album
SELECT 
  'album' AS table_name,
  SUM(album_id IS NULL) AS missing_album_id,
  SUM(title IS NULL) AS missing_title,
  SUM(artist_id IS NULL) AS missing_artist_id
FROM album;

-- Duplicate Primary Key Check for album
SELECT album_id, COUNT(*) AS duplicate_count
FROM album
GROUP BY album_id
HAVING COUNT(*) > 1;

-- NULL Check for artist
SELECT
  'artist' AS table_name,
  SUM(artist_id IS NULL) AS missing_artist_id,
  SUM(name IS NULL) AS missing_name
FROM artist;

-- Duplicate Primary Key Check for artist
SELECT artist_id, COUNT(*) AS duplicate_count
FROM artist
GROUP BY artist_id
HAVING COUNT(*) > 1;

SELECT 
-- NULL Check for employee
  'employee' AS table_name,
  SUM(employee_id IS NULL) AS missing_employee_id,
  SUM(last_name IS NULL) AS missing_last_name,
  SUM(first_name IS NULL) AS missing_first_name,
  SUM(title IS NULL) AS missing_title,
  SUM(reports_to IS NULL) AS missing_reports_to,
  SUM(birthdate IS NULL) AS missing_birthdate,
  SUM(hire_date IS NULL) AS missing_hire_date,
  SUM(address IS NULL) AS missing_address,
  SUM(city IS NULL) AS missing_city,
  SUM(state IS NULL) AS missing_state,
  SUM(country IS NULL) AS missing_country,
  SUM(city IS NULL) AS missing_city,
  SUM(email IS NULL) AS missing_email
FROM employee;

-- Duplicate Primary Key Check for employee
SELECT employee_id, COUNT(*) AS duplicate_count
FROM employee
GROUP BY employee_id
HAVING COUNT(*) > 1;

-- NULL Check for playlist
SELECT 
  'playlist' AS table_name,
  SUM(playlist_id IS NULL) AS missing_playlist_id,
  SUM(name IS NULL) AS missing_name
FROM playlist;

-- Duplicate Primary Key Check for playlist
SELECT playlist_id, COUNT(*) AS duplicate_count
FROM playlist
GROUP BY playlist_id
HAVING COUNT(*) > 1;

-- NULL Check for media_type
SELECT 
  'media_type' AS table_name,
  SUM(media_type_id IS NULL) AS missing_media_type_id,
  SUM(name IS NULL) AS missing_name
FROM media_type;

-- Duplicate Primary Key Check for media_type
SELECT media_type_id, COUNT(*) AS duplicate_count
FROM media_type
GROUP BY media_type_id
HAVING COUNT(*) > 1;

-- NULL Check for genre
SELECT 
  'genre' AS table_name,
  SUM(genre_id IS NULL) AS missing_genre_id,
  SUM(name IS NULL) AS missing_name
FROM genre;

-- Duplicate Primary Key Check for genre
SELECT genre_id, COUNT(*) AS duplicate_count
FROM genre
GROUP BY genre_id
HAVING COUNT(*) > 1;

-----------------------------------------------------------------------------------------------------------------------------------------------
#Question 2: Find the top-selling tracks and top artists in the USA and identify their most famous genres.

-- Top-selling tracks in the USA with their artists and genres
SELECT 
t.name AS track_name,ar.name AS artist_name,g.name AS genre_name,SUM(il.unit_price * il.quantity) AS total_sales
FROM invoice i
JOIN customer c ON i.customer_id = c.customer_id
JOIN invoice_line il ON i.invoice_id = il.invoice_id
JOIN track t ON il.track_id = t.track_id
JOIN album al ON t.album_id = al.album_id
JOIN artist ar ON al.artist_id = ar.artist_id
JOIN genre g ON t.genre_id = g.genre_id
WHERE c.country = 'USA'
GROUP BY t.name, ar.name, g.name
ORDER BY total_sales DESC
LIMIT 10;

-----------------------------------------------------------------------------------------------------------------------------------------------
# Question 3:What is the customer demographic breakdown (age, gender, location) of Chinook's customer base?

SELECT
  COALESCE(country, 'Unknown') AS country,
  COALESCE(state, 'Unknown') AS state,
  COALESCE(city, 'Unknown') AS city,
  COUNT(*) AS total_customers
FROM customer
GROUP BY country, state, city
ORDER BY total_customers DESC;
-----------------------------------------------------------------------------------------------------------------------------------------------
#Question Number 4 :Calculate the total revenue and number of invoices for each country, state, and city
SELECT 
    c.country,
    COALESCE(c.state, 'Unknown') AS state,
    COALESCE(c.city, 'Unknown') AS city,
    COUNT(i.invoice_id) AS number_of_invoices,
    ROUND(SUM(i.total), 2) AS total_revenue
FROM customer c
JOIN invoice i ON c.customer_id = i.customer_id
GROUP BY c.country, c.state, c.city
ORDER BY total_revenue DESC;
-----------------------------------------------------------------------------------------------------------------------------------------------
#Question Number 5 : 

with customer_revenue as (
  select 
    c.customer_id,
    c.first_name,
    c.last_name,
    c.country,
    sum(i.total) as total_revenue
  from customer c
  join invoice i on c.customer_id = i.customer_id
  group by c.customer_id, c.first_name, c.last_name, c.country
),
ranked_customers as (
  select *,
         row_number() over(partition by country order by total_revenue desc) as rn
  from customer_revenue
)
select 
  customer_id,
  first_name,
  last_name,
  country,
  total_revenue
from ranked_customers
where rn <= 5
order by country, total_revenue desc;
-----------------------------------------------------------------------------------------------------------------------------------------------
#Question number 6:

with customer_track_sales as (
  select
    c.customer_id,
    c.first_name,
    c.last_name,
    t.track_id,
    t.name as track_name,
    sum(ii.quantity) as total_quantity
  from customer c
  join invoice i on c.customer_id = i.customer_id
  join invoice_line ii on i.invoice_id = ii.invoice_id
  join track t on ii.track_id = t.track_id
  group by c.customer_id, t.track_id
),
ranked_tracks as (
  select *,
    row_number() over (partition by customer_id order by total_quantity desc) as ranking
  from customer_track_sales
  
)
select
  customer_id,
  first_name,
  last_name,
  track_id,
  track_name,
  total_quantity
from ranked_tracks
where ranking = 1
order by customer_id;
-----------------------------------------------------------------------------------------------------------------------------------------------
#Question 7 :
-- Frequency of purchases (number of invoices per customer)
select 
c.customer_id,
concat(c.first_name, ' ', c.last_name) as customer_name,
count(i.invoice_id) as total_purchases,
round(avg(i.total), 2) as average_order_value,
round(sum(i.total), 2) as total_spent
from customer c
join invoice i on c.customer_id = i.customer_id
group by c.customer_id, customer_name
order by total_spent desc;
-----------------------------------------------------------------------------------------------------------------------------------------------

#Question 8 : What is customers churn rate?

with customer_activity as (
    select 
        c.customer_id,
        max(i.invoice_date) as last_purchase_date
    from customer c
    join invoice i on c.customer_id = i.customer_id
    group by c.customer_id
),
churn_cutoff as (
    select date_sub(max(invoice_date), interval 6 month) as cutoff_date
    from invoice
),
status_counts as (
    select 
        case 
            when ca.last_purchase_date < cc.cutoff_date then 'churned'
            else 'active'
        end as customer_status,
        count(*) as customer_count
    from customer_activity ca
    cross join churn_cutoff cc
    group by customer_status
),
totals as (
    select sum(customer_count) as total_customers from status_counts
)
select 
    sc.customer_status,
    sc.customer_count,
    round(sc.customer_count / t.total_customers * 100, 2) as churn_rate_percent
from status_counts sc
cross join totals t;
-----------------------------------------------------------------------------------------------------------------------------------------------
#Question 9 :

with usa_sales as (
    select 
        g.name as genre,
        ar.name as artist,
        il.unit_price * il.quantity as sale_amount
    from invoice i
    join invoice_line il on i.invoice_id = il.invoice_id
    join track t on il.track_id = t.track_id
    join genre g on t.genre_id = g.genre_id
    join album al on t.album_id = al.album_id
    join artist ar on al.artist_id = ar.artist_id
    where i.billing_country = 'USA'
),
genre_sales as (
    select 
        genre,
        sum(sale_amount) as genre_total
    from usa_sales
    group by genre
),
artist_sales as (
    select 
        artist,
        sum(sale_amount) as artist_total
    from usa_sales
    group by artist
),
total_sales as (
    select sum(genre_total) as total_usa_sales from genre_sales
),
genre_percent as (
    select 
        genre,
        round(genre_total, 2) as total_sales,
        round(genre_total / ts.total_usa_sales * 100, 2) as percentage_of_total_sales
    from genre_sales
    cross join total_sales ts
)

select 
    'genre' as type,
    genre as name,
    total_sales,
    percentage_of_total_sales
from genre_percent

union all

select 
    'artist' as type,
    artist as name,
    round(artist_total, 2) as total_sales,
    null as percentage_of_total_sales
from artist_sales
order by total_sales desc;

----------------------------------------------------------------------------------------------------------------------------------------

#Question 10 : Find customer who have purchased tracks from atleast 3 different genres

with customer_genres as (
    select 
        c.customer_id,
        g.name as genre
    from customer c
    join invoice i on c.customer_id = i.customer_id
    join invoice_line il on i.invoice_id = il.invoice_id
    join track t on il.track_id = t.track_id
    join genre g on t.genre_id = g.genre_id
    group by c.customer_id, g.name
),
genre_count as (
    select 
        customer_id,
        count(distinct genre) as genre_count
    from customer_genres
    group by customer_id
)
select 
    c.customer_id,
    concat(c.first_name, ' ', c.last_name) as customer_name,
    gc.genre_count
from genre_count gc
join customer c on c.customer_id = gc.customer_id
where gc.genre_count >= 3
order by gc.genre_count desc;
-----------------------------------------------------------------------------------------------------------------------------------------
#Question 11 : Rank genres based on their sales performance in the USA 

with usa_sales as (
    select 
        g.name as genre,
        il.unit_price * il.quantity as sale_amount
    from invoice i
    join invoice_line il on i.invoice_id = il.invoice_id
    join track t on il.track_id = t.track_id
    join genre g on t.genre_id = g.genre_id
    where i.billing_country = 'USA'
),
genre_sales as (
    select 
        genre,
        sum(sale_amount) as total_sales
    from usa_sales
    group by genre
)
select 
    genre,
    round(total_sales, 2) as total_sales,
    dense_rank() over (order by total_sales desc) as sales_rank
from genre_sales
order by sales_rank;

---------------------------------------------------------------------------------------------------------------------------------------
#Question Number 12 : Identify customers who have not made a purchase in the last 3 months
with customer_last_purchase as (
    select 
        c.customer_id,
        concat(c.first_name, ' ', c.last_name) as customer_name,
        max(i.invoice_date) as last_purchase_date
    from customer c
    join invoice i on c.customer_id = i.customer_id
    group by c.customer_id
),
latest_invoice as (
    select max(invoice_date) as latest_date from invoice
),
inactive_customers as (
    select 
        clp.customer_id,
        clp.customer_name,
        clp.last_purchase_date,
        l.latest_date
    from customer_last_purchase clp
    cross join latest_invoice l
    where clp.last_purchase_date < date_sub(l.latest_date, interval 3 month)
)
select * from inactive_customers
order by last_purchase_date;

-------------------------------------------------------------------
#SUBJECTIVE 
#Question 1 :
#Recommend the three albums from the new record label that should be prioritised for advertising and promotion in the USA based on genre sales analysis

with usa_sales as (
    select 
        al.album_id,
        al.title as album_title,
        ar.name as artist_name,
        g.name as genre,
        il.unit_price * il.quantity as sale_amount
    from invoice i
    join invoice_line il on i.invoice_id = il.invoice_id
    join track t on il.track_id = t.track_id
    join album al on t.album_id = al.album_id
    join artist ar on al.artist_id = ar.artist_id
    join genre g on t.genre_id = g.genre_id
    where i.billing_country = 'USA'
),
album_sales as (
    select 
        album_id,
        album_title,
        artist_name,
        genre,
        round(sum(sale_amount), 2) as total_sales
    from usa_sales
    group by album_id, album_title, artist_name, genre
)

select 
    album_title,
    artist_name,
    genre,
    total_sales,
    dense_rank() over (order by total_sales desc) as sales_rank
from album_sales
order by sales_rank;
----------------------------------------------------------------------------

#Question 2 :
#Determine the top-selling genres in countries other than the USA and identify any commonalities or differences.


with non_usa_sales as (
    select 
        g.name as genre,
        i.billing_country,
        il.unit_price * il.quantity as sale_amount
    from invoice i
    join invoice_line il on i.invoice_id = il.invoice_id
    join track t on il.track_id = t.track_id
    join genre g on t.genre_id = g.genre_id
    where i.billing_country != 'USA'
),
genre_sales_by_country as (
    select 
        billing_country,
        genre,
        round(sum(sale_amount), 2) as total_sales
    from non_usa_sales
    group by billing_country, genre
),
ranked_genres as (
    select *,
			dense_rank() over (partition by billing_country order by total_sales desc) as genre_rank
    from genre_sales_by_country
)
select billing_country,genre,total_sales
from ranked_genres
where genre_rank <= 1
order by total_sales desc;
-----------------------------------------------------------------

#Question 3 :Customer Purchasing Behavior Analysis: How do the purchasing habits (frequency, basket size, spending amount) of long-term customers differ from those of new customers? What insights can these patterns provide about customer loyalty and retention strategies?


with customer_signup as (
    select 
        customer_id,
        min(invoice_date) as signup_date
    from invoice
    group by customer_id
),
tagged_customers as (
    select 
        c.customer_id,
        c.first_name,
        c.last_name,
        cs.signup_date,
        max(i.invoice_date) as last_purchase_date,
        datediff(max(i.invoice_date), cs.signup_date) as active_days,
        case 
            when datediff(max(i.invoice_date), cs.signup_date) > 180 then 'long_term'
            else 'new'
        end as customer_type
    from customer c
    join customer_signup cs on c.customer_id = cs.customer_id
    join invoice i on c.customer_id = i.customer_id
    group by c.customer_id, c.first_name, c.last_name, cs.signup_date
),
customer_behavior as (
    select 
        tc.customer_type,
        count(distinct i.invoice_id) as total_purchases,
        round(avg(il.quantity), 2) as avg_basket_size,
        round(sum(il.unit_price * il.quantity) / count(distinct i.customer_id), 2) as avg_spend_per_customer
    from tagged_customers tc
    join invoice i on tc.customer_id = i.customer_id
    join invoice_line il on i.invoice_id = il.invoice_id
    group by tc.customer_type
)

select * from customer_behavior;
----------------------------------------------------------------------------------------------------------------
#Question 4 : Product Affinity Analysis: Which music genres, artists, or albums are frequently purchased together by customers? How can this information guide product recommendations and cross-selling initiatives?

with invoice_genres as (
    select 
        i.invoice_id,
        g.name as genre
    from invoice i
    join invoice_line il on i.invoice_id = il.invoice_id
    join track t on il.track_id = t.track_id
    join genre g on t.genre_id = g.genre_id
),
genre_pairs as (
    select 
        a.genre as genre_1,
        b.genre as genre_2,
        count(distinct a.invoice_id) as times_bought_together
    from invoice_genres a
    join invoice_genres b 
        on a.invoice_id = b.invoice_id and a.genre < b.genre
    group by a.genre, b.genre
    order by times_bought_together desc
)

select * from genre_pairs
limit 15;
-----------------------------------------------------------------------------------
#Question 5 :Regional Market Analysis: Do customer purchasing behaviors and churn rates vary across different geographic regions or store locations? How might these correlate with local demographic or economic factors?
with customer_first_last as (
    select 
        c.customer_id,
        c.country,
        min(i.invoice_date) as first_purchase,
        max(i.invoice_date) as last_purchase
    from customer c
    join invoice i on c.customer_id = i.customer_id
    group by c.customer_id, c.country
),
latest_date as (
    select max(invoice_date) as latest_invoice_date from invoice
),
tagged_customers as (
    select 
        cf.country,
        cf.customer_id,
        cf.last_purchase,
        case 
            when datediff(ld.latest_invoice_date, cf.last_purchase) > 180 then 'churned'
            else 'active'
        end as status
    from customer_first_last cf
    join latest_date ld
),
country_churn_summary as (
    select 
        country,
        sum(case when status = 'churned' then 1 else 0 end) as churned_customers,
        sum(case when status = 'active' then 1 else 0 end) as active_customers,
        count(*) as total_customers,
        round(sum(case when status = 'churned' then 1 else 0 end) / count(*) * 100, 2) as churn_rate
    from tagged_customers
    group by country
),
country_spend as (
    select 
        c.country,
        round(sum(il.unit_price * il.quantity) / count(distinct c.customer_id), 2) as avg_spend_per_customer,
        count(distinct i.invoice_id) as total_purchases
    from customer c
    join invoice i on c.customer_id = i.customer_id
    join invoice_line il on i.invoice_id = il.invoice_id
    group by c.country
)
select 
    cs.country,
    cs.total_customers,
    cs.active_customers,
    cs.churned_customers,
    cs.churn_rate,
    sp.total_purchases,
    sp.avg_spend_per_customer
from country_churn_summary cs
join country_spend sp on cs.country = sp.country
order by churn_rate desc;


---------------------------------------------------------------------------------------
#Question 6  :Customer Risk Profiling: Based on customer profiles (age, gender, location, purchase history), which customer segments are more likely to churn or pose a higher risk of reduced spending? What factors contribute to this risk?

with customer_purchase_summary as (
    select 
        c.customer_id,
        c.country,
        count(distinct i.invoice_id) as total_purchases,
        round(sum(il.unit_price * il.quantity), 2) as total_spent,
        max(i.invoice_date) as last_purchase
    from customer c
    join invoice i on c.customer_id = i.customer_id
    join invoice_line il on i.invoice_id = il.invoice_id
    group by c.customer_id, c.country
),
latest_date as (
    select max(invoice_date) as latest_invoice_date from invoice
),
risk_tagged_customers as (
    select 
        cps.customer_id,
        cps.country,
        cps.total_purchases,
        cps.total_spent,
        case 
            when datediff(ld.latest_invoice_date, cps.last_purchase) > 180 then 'churned'
            else 'active'
        end as churn_status
    from customer_purchase_summary cps
    join latest_date ld
)
select * from risk_tagged_customers
order by churn_status desc, total_spent;
--------------------------------------------------------------------------------------------

#Question 7 : Customer Lifetime Value Modeling: How can you leverage customer data (tenure, purchase history, engagement) to predict the lifetime value of different customer segments? 


with customer_summary as (
    select 
        c.customer_id,
        c.country,
        min(i.invoice_date) as first_purchase,
        max(i.invoice_date) as last_purchase,
        count(distinct i.invoice_id) as total_purchases,
        round(sum(il.unit_price * il.quantity), 2) as total_spent
    from customer c
    join invoice i on c.customer_id = i.customer_id
    join invoice_line il on i.invoice_id = il.invoice_id
    group by c.customer_id, c.country
),
tenure_calc as (
    select 
        cs.*,
        timestampdiff(month, cs.first_purchase, cs.last_purchase) as tenure_months,
        round(cs.total_spent / cs.total_purchases, 2) as avg_order_value,
        round(cs.total_purchases / nullif(timestampdiff(month, cs.first_purchase, cs.last_purchase), 0), 2) as purchase_frequency
    from customer_summary cs
),
ltv_calc as (
    select 
        *,
        round(avg_order_value * purchase_frequency * tenure_months, 2) as estimated_ltv
    from tenure_calc
),
latest_invoice as (
    select max(invoice_date) as latest_date from invoice
),
final as (
    select 
        l.*,
        case 
            when datediff(li.latest_date, l.last_purchase) > 180 then 'churned'
            else 'active'
        end as churn_status
    from ltv_calc l
    join latest_invoice li
)
select * from final
order by estimated_ltv desc;

----------------------------------------------------------

#Question 10 :How can you alter the "Albums" table to add a new column named "ReleaseYear" of type INTEGER to store the release year of each album?

alter table albums
add column ReleaseYear integer;
update albums
set releaseyear = 2001
where albumid = 1;
-------------------------------------------------------------------------------------
#Question 11 :Chinook is interested in understanding the purchasing behavior of customers based on their geographical location. They want to know the average total amount spent by customers from each country, along with the number of customers and the average number of tracks purchased per customer. Write an SQL query to provide this information.

with customer_purchase as (
    select 
        c.customer_id,
        c.country,
        sum(il.unit_price * il.quantity) as total_spent,
        sum(il.quantity) as total_tracks
    from customer c
    join invoice i on c.customer_id = i.customer_id
    join invoice_line il on i.invoice_id = il.invoice_id
    group by c.customer_id, c.country
)
select 
    country,
    count(customer_id) as total_customers,
    round(avg(total_spent), 2) as avg_spent_per_customer,
    round(avg(total_tracks), 2) as avg_tracks_per_customer
from customer_purchase
group by country
order by avg_spent_per_customer desc;



